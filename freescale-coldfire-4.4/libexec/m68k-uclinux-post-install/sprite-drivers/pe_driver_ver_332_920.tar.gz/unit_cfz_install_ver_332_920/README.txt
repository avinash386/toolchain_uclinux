Thank you for purchasing P&E�s Linux BDM Interface Libraries.  This document outlines some of the important considerations to keep in mind when installing the P&E libraries and the associated USB drivers.  

1. Installing USB Drivers

The P&E BDM Libraries can be used on any Linux platform without further modification, however the USB drivers which the libraries rely on must be built against a particular distribution prior to usage of the P&E BDM Libraries.  This is a process which requires a small degree of expertise in building Linux kernels and this document assumes that the user already has a familiarity with, as well as has downloaded the various source and binary components necessary to rebuild the Kernel.  

Linux distributions can be significantly different from one another in terms of the directory structures where source and header files are kept as well as the components provided.  For example, many modern distributions don�t come with gcc.  We have compiled a list of components which need to be installed for various Linux distributions which can serve as a guide for getting the components necessary to build kernel on other distributions.  These dependencies are outlined in the Linux_Distro_Dependencies.pdf file found in the same archive.

Asides from the above, before building the kernel please make sure to refer to the documentation provided by the USB driver supplier (Jungo) which can be found at the following location:

http://www.jungo.com//st/support/installation_instructions.html

This is where you can find the most up-to-date instructions for building the USB drivers (WinDriver) against the Kernel.

Please note that it is not always necessary to rebuild the Kernel, but rebuilding it is what guarantees that you generate all the files necessary in order for WinDriver to successfully build against the Kernel.

2. Installing P&E ColdFire drivers

Uncompress unit_cfz_install_ver.xxx_yyy into a desired directory.  The numbers xxx and yyy stand for versions of the ColdFire and USB drivers. For example unit_cfz_install_ver_332_920.tar.gz refers to P&E's ColdFire driver version 3.32 and Windriver's USB driver version 9.20.

Installation steps are as follows: 

1. User must have root privileges. You can log in as root or issue su command inside the shell terminal. 
2. Change into the unit_cfz_install_ver.xxx_yyy (where you uncompressed P&E's unit_cfz library) directory and issue the �sh setup.sh� command at the command prompt.
3. This command will execute the installation script, which will first install the USB drivers and then install the P&E BDM Libraries.  At the end of the script, it will indicate whether the installation has been successful.
   
3. Using P&E ColdFire Drivers 

There are several methods to test P&E unit_cfz module. We provide example programs written in C++ and Kylix. Both are subdirectories inside the unit_cfz folder. 

To test the module using our c++ example, attach P&E Multilink to the target, attach USB cable to the Multilink - blue led will light up. Make sure that the blue and orange lights are lit on the cable. The blue light indicates linux distribution has detected the Multilink cable. The orange light indicates that Multilink cable detects power to the target. 

To compile and run one of the example files you can:

1. Switch into directory cpp_testcfz and issue �g++ testcfz.cpp �ldl� to compile the code
2. If the compilation and linking did not produce any errors, testcfz_app will be located inside the cpp_testcfz folder and you can run it by issuing �./a.out� command.

Please keep in mind that for automatic firmware upgrades to take place, the firmware upgrade files (which can be found in the PE_Firmware folder) must be located at the same location of the executable application.
